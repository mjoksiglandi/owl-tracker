#include <Arduino.h>
#include <SPI.h>
#include <U8g2lib.h>
#include "board_pins.h"
#include "oled_display.h"

// HW SPI SSD1322 256x64
U8G2_SSD1322_NHD_256X64_F_4W_HW_SPI u8g2(
  U8G2_R0, /*cs=*/OLED_PIN_CS, /*dc=*/OLED_PIN_DC, /*reset=*/OLED_PIN_RST
);

static inline int clampi(int v, int lo, int hi){ return v<lo?lo:(v>hi?hi:v); }
static inline float nzf(float v){ return isnan(v)?0.0f:v; }
static inline double nzd(double v){ return isnan(v)?0.0:v; }

// ---------------- Iconos mini (12 px alto) ----------------
static void drawAntennaMini(int x, int y){ // base en y
  u8g2.drawBox(x, y-8, 2, 8);
  u8g2.drawBox(x-2, y-3, 6, 2);
}
static void drawBarsMini(int x, int y, uint8_t level, uint8_t maxBars, uint8_t w=2, uint8_t step=2){
  for (uint8_t i=0;i<maxBars;i++){
    int h = 2 + i*2;                 // 2,4,6,8,10
    int yy = y - h;
    int xx = x + i*(w+step);
    if (i < level) u8g2.drawBox(xx, yy, w, h);
    else           u8g2.drawFrame(xx, yy, w, h);
  }
}
static void drawSatelliteMini(int x, int y){
  u8g2.drawCircle(x+5, y-6, 5, U8G2_DRAW_ALL);
  u8g2.drawLine(x+1, y-6, x+9, y-6);
  u8g2.drawLine(x+5, y-10, x+5, y-2);
}
static void drawGlobeMini(int x, int y){
  u8g2.drawCircle(x+5, y-6, 5, U8G2_DRAW_ALL);
  u8g2.drawLine(x+1, y-6, x+9, y-6);
  u8g2.drawLine(x+5, y-10, x+5, y-2);
  u8g2.drawEllipse(x+5, y-6, 4, 2, U8G2_DRAW_ALL);
}

// ---------------- CSQ->barras (0..5) ----------------
static uint8_t csq_to_bars(int csq){
  if (csq<0 || csq==99) return 0;
  if (csq<=3)  return 1;
  if (csq<=9)  return 2;
  if (csq<=15) return 3;
  if (csq<=22) return 4;
  return 5;
}

// ---------------- Strings helpers ----------------
static String fmtCoord(double v, bool isLat){
  if (isnan(v)) return isLat? "Lat: --.--" : "Lon: --.--";
  char buf[32];
  snprintf(buf, sizeof(buf), "%s%.6f", (isLat?(v<0?"S ":"N "):(v<0?"W ":"E ")), fabs(v));
  return String(buf);
}
static String fmtAlt(double a){
  if (isnan(a)) return "Alt: -- m";
  char buf[24]; snprintf(buf, sizeof(buf), "Alt: %.1f m", a);
  return String(buf);
}
static String fmtSpeed(float s){
  if (isnan(s)) return "Spd: --.- m/s";
  char buf[24]; snprintf(buf, sizeof(buf), "Spd: %.1f m/s", s);
  return String(buf);
}
static String fmtCourse(float c){
  if (isnan(c)) return "Trk: ---";
  char buf[20]; snprintf(buf, sizeof(buf), "Trk: %.0f", c);
  return String(buf);
}
static String fmtPdop(float p){
  if (p<0) return "PDOP: --";
  char buf[20]; snprintf(buf, sizeof(buf), "PDOP: %.1f", p);
  return String(buf);
}
static String fmtMsgs(uint32_t n){
  char buf[24]; snprintf(buf, sizeof(buf), "MSG: %lu", (unsigned long)n);
  return String(buf);
}
static String fmtUtc(const String& s){
  return s.length() ? s : String("--:--:--Z");
}

// ---------------- Init ----------------
bool oled_init(){
  SPI.begin(OLED_PIN_SCK, /*MISO*/-1, OLED_PIN_MOSI, OLED_PIN_CS);
  pinMode(OLED_PIN_RST, OUTPUT);
  digitalWrite(OLED_PIN_RST, LOW);  delay(10);
  digitalWrite(OLED_PIN_RST, HIGH); delay(10);

  u8g2.begin();
  u8g2.setContrast(210);
  return true;
}

void oled_splash(const char* title){
  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_logisoso20_tr);
  int w = u8g2.getStrWidth(title);
  u8g2.drawStr((256-w)/2, 38, title);
  u8g2.setFont(u8g2_font_6x12_tf);
  u8g2.drawStr(70, 58, "booting...");
  u8g2.sendBuffer();
}

// =============================================================
//  HOME / DASHBOARD
//  - Top mini-icons + barras (CEL, GPS, IR) + MSG a la derecha
//  - Separadores horizontales
//  - Centro: Lat | Lon | Alt   (y debajo Spd)
//  - Inferior: PDOP (izq) | UTC (centro)
// =============================================================
void oled_draw_dashboard(const OwlUiData& d){
  u8g2.clearBuffer();

  // ---------- Top ----------
  int topY = 12;  // mini altura
  u8g2.drawHLine(0, 16, 256);   // separador

  // CEL
  drawAntennaMini(6, topY);
  uint8_t bars = csq_to_bars(d.csq);
  drawBarsMini(14, topY, clampi(bars,0,5), 5, 2, 2);
  u8g2.setFont(u8g2_font_5x8_tf);
  u8g2.drawStr(14 + 5*(2+2) + 4, topY, "CEL");

  // GPS centro top
  int xgps = 104;
  drawSatelliteMini(xgps, topY);
  char gpsBuf[20];
  if (d.sats >= 0) snprintf(gpsBuf, sizeof(gpsBuf), "GPS %02d", d.sats);
  else             snprintf(gpsBuf, sizeof(gpsBuf), "GPS --");
  u8g2.drawStr(xgps + 14, topY, gpsBuf);

  // IR derecha top
  int xir = 190;
  drawGlobeMini(xir, topY);
  if (d.iridiumLvl < 0) {
    u8g2.drawStr(xir + 14, topY, "IR --");
  } else {
    uint8_t irBars = clampi(d.iridiumLvl, 0, 5);
    drawBarsMini(xir + 14, topY, irBars, 5, 2, 2);
    u8g2.drawStr(xir + 14 + 5*(2+2) + 4, topY, "IR");
  }

  // Mensajes (contador en top derecha)
  String sMsgTop = fmtMsgs(d.msgRx);
  int wMsgTop = u8g2.getStrWidth(sMsgTop.c_str());
  u8g2.drawStr(256 - 6 - wMsgTop, topY, sMsgTop.c_str());

  // ---------- Centro ----------
  u8g2.setFont(u8g2_font_6x12_tf);
  String sLat = fmtCoord(d.lat, true);
  String sLon = fmtCoord(d.lon, false);
  String sAlt = fmtAlt(d.alt);
  String sSpd = fmtSpeed(d.speed_mps);

  u8g2.drawStr(6, 34,  sLat.c_str());
  u8g2.drawStr(90, 34, sLon.c_str());
  int wAlt = u8g2.getStrWidth(sAlt.c_str());
  u8g2.drawStr(256 - 6 - wAlt, 34, sAlt.c_str());

  // Spd debajo de Alt (simetría)
  int wSpd = u8g2.getStrWidth(sSpd.c_str());
  u8g2.drawStr(256 - 6 - wSpd, 48, sSpd.c_str());

  // separador sección inferior
  u8g2.drawHLine(0, 52, 256);

  // ---------- Inferior ----------
  String sPdop = fmtPdop(d.pdop);
  String sUtc  = fmtUtc(d.utc);

  u8g2.drawStr(6, 62, sPdop.c_str());                  // izq
  int wUtc = u8g2.getStrWidth(sUtc.c_str());
  u8g2.drawStr((256 - wUtc)/2, 62, sUtc.c_str());      // centro

  u8g2.sendBuffer();
}

// =============================================================
//  GPS DETAIL
//  - Sin barra superior, más info: Trk con cardinal
// =============================================================
static const char* cardinal(float deg) {
  if (isnan(deg)) return "---";
  static const char* dirs[]={"N","NNE","NE","ENE","E","ESE","SE","SSE",
                             "S","SSW","SW","WSW","W","WNW","NW","NNW"};
  int idx = (int)floor((deg/22.5f)+0.5f) & 15;
  return dirs[idx];
}
void oled_draw_gps_detail(const OwlUiData& d){
  u8g2.clearBuffer();

  u8g2.setFont(u8g2_font_7x14_tf);
  u8g2.drawStr(6, 14, "GPS Detail");
  u8g2.drawHLine(0, 18, 256);

  u8g2.setFont(u8g2_font_6x12_tf);
  char ln1[64]; snprintf(ln1, sizeof(ln1), "Sats: %02d   PDOP: %s",
                         d.sats<0?0:d.sats,
                         (d.pdop<0?"--":String(d.pdop,1).c_str()));
  u8g2.drawStr(6, 34, ln1);

  String s1 = fmtCoord(d.lat, true);
  String s2 = fmtCoord(d.lon, false);
  u8g2.drawStr(6, 48, s1.c_str());
  u8g2.drawStr(6, 62, s2.c_str());

  // Alt + Spd + Trk (con cardinal)
  String sAlt = fmtAlt(d.alt);
  String sSpd = fmtSpeed(d.speed_mps);
  String sTrk = String("Trk: ") + (isnan(d.course_deg)?"---":String(d.course_deg,0)) +
                " " + cardinal(d.course_deg);

  int wAlt = u8g2.getStrWidth(sAlt.c_str());
  int wSpd = u8g2.getStrWidth(sSpd.c_str());
  int wTrk = u8g2.getStrWidth(sTrk.c_str());

  // Columna derecha (arriba-abajo)
  u8g2.drawStr(256-6-wAlt, 34, sAlt.c_str());
  u8g2.drawStr(256-6-wSpd, 48, sSpd.c_str());
  u8g2.drawStr(256-6-wTrk, 62, sTrk.c_str());

  u8g2.sendBuffer();
}

// =============================================================
//  IRIDIUM DETAIL (simple)
// =============================================================
void oled_draw_iridium_detail(bool present, int sigLevel, int unread, const String& imei){
  u8g2.clearBuffer();

  u8g2.setFont(u8g2_font_7x14_tf);
  u8g2.drawStr(6, 14, "Iridium Detail");
  u8g2.drawHLine(0, 18, 256);

  u8g2.setFont(u8g2_font_6x12_tf);
  String sPr = String("Present: ") + (present?"YES":"NO");
  u8g2.drawStr(6, 34, sPr.c_str());

  char ln1[48];
  snprintf(ln1, sizeof(ln1), "Signal: %s",
          (sigLevel<0?"--":String(sigLevel).c_str()));
  u8g2.drawStr(6, 48, ln1);

  String sIMEI = String("IMEI: ") + (imei.length()?imei:"--");
  u8g2.drawStr(6, 62, sIMEI.c_str());

  // Unread (derecha)
  String sU = String("MT: ") + (unread>=0?String(unread):String("--"));
  int wU = u8g2.getStrWidth(sU.c_str());
  u8g2.drawStr(256-6-wU, 34, sU.c_str());

  u8g2.sendBuffer();
}

// =============================================================
//  GSM DETAIL (nuevo)
// =============================================================
void oled_draw_gsm_detail(const OwlUiData& d,
                          const String& imei,
                          bool netReg,
                          bool pdpUp,
                          int rssiDbm)
{
  u8g2.clearBuffer();

  u8g2.setFont(u8g2_font_7x14_tf);
  u8g2.drawStr(6, 14, "GSM / LTE Detail");
  u8g2.drawHLine(0, 18, 256);

  u8g2.setFont(u8g2_font_6x12_tf);
  char ln1[64];
  snprintf(ln1, sizeof(ln1), "CSQ: %d   RSSI: %d dBm", d.csq, rssiDbm);
  u8g2.drawStr(6, 34, ln1);

  char ln2[64];
  snprintf(ln2, sizeof(ln2), "Net: %s   PDP: %s", netReg ? "REGISTERED" : "NO",
                                              pdpUp  ? "UP"         : "DOWN");
  u8g2.drawStr(6, 48, ln2);

  String sImei = String("IMEI: ") + (imei.length()?imei:"--");
  u8g2.drawStr(6, 62, sImei.c_str());

  u8g2.sendBuffer();
}

// =============================================================
//  BLE DETAIL (nuevo)
// =============================================================
void oled_draw_ble_detail(bool connected, const String& devName)
{
  u8g2.clearBuffer();

  u8g2.setFont(u8g2_font_7x14_tf);
  u8g2.drawStr(6, 14, "BLE Detail");
  u8g2.drawHLine(0, 18, 256);

  u8g2.setFont(u8g2_font_6x12_tf);
  const char* st = connected ? "CONNECTED" : "ADVERTISING";
  char ln1[64];
  snprintf(ln1, sizeof(ln1), "Status: %s", st);
  u8g2.drawStr(6, 34, ln1);

  String nm = String("Name: ") + (devName.length()?devName:"OwlTracker");
  u8g2.drawStr(6, 48, nm.c_str());

  u8g2.drawStr(6, 62, "BTN1 long: cycle screens");

  u8g2.sendBuffer();
}

// =============================================================
//  SYS CONFIG (ya presente en tu proyecto) y MESSAGES (stub)
//  — deja tus implementaciones actuales si ya existen —
// =============================================================
void oled_draw_sys_config(const OwlUiData& d, bool netReg, bool pdpUp,
                          const String& ip, bool sdOk, bool i2cOk, const char* fw) {
  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_7x14_tf);
  u8g2.drawStr(6, 14, "System Config");
  u8g2.drawHLine(0, 18, 256);

  u8g2.setFont(u8g2_font_6x12_tf);
  char ln1[64]; snprintf(ln1, sizeof(ln1), "Net: %s   PDP: %s", netReg?"REG":"NO", pdpUp?"UP":"DOWN");
  u8g2.drawStr(6, 34, ln1);

  String ipS = String("IP: ") + (ip.length()?ip:"--");
  u8g2.drawStr(6, 48, ipS.c_str());

  char ln2[64]; snprintf(ln2, sizeof(ln2), "SD: %s   I2C: %s", sdOk?"OK":"NO", i2cOk?"OK":"NO");
  u8g2.drawStr(6, 62, ln2);

  // fw a la derecha
  int w = u8g2.getStrWidth(fw);
  u8g2.drawStr(256-6-w, 34, fw);

  u8g2.sendBuffer();
}

void oled_draw_messages(uint16_t unread, const String& last){
  u8g2.clearBuffer();

  u8g2.setFont(u8g2_font_7x14_tf);
  u8g2.drawStr(6, 14, "Messages");
  u8g2.drawHLine(0, 18, 256);

  u8g2.setFont(u8g2_font_6x12_tf);
  char ln1[32]; snprintf(ln1, sizeof(ln1), "Unread: %u", unread);
  u8g2.drawStr(6, 34, ln1);

  String sLast = String("Last: ") + (last.length()?last:"--");
  u8g2.drawStr(6, 48, sLast.c_str());

  u8g2.drawStr(6, 62, "BTN1 long: cycle screens");
  u8g2.sendBuffer();
}
