#pragma once

enum class UiScreen : uint8_t {
  HOME = 0,        // dashboard principal
  GPS_DETAIL,      // desglose GPS
  IRIDIUM_DETAIL,  // (futuro)
  SYS_CONFIG,      // configuración simple
  MESSAGES         // bandeja de mensajes
};
